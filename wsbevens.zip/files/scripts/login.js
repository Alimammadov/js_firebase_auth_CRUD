$(document).ready(function () {
    // Initialize Firebase
    var config = {
        apiKey: "AIzaSyCdtLZwM1uMAAt9xDtjllkul0QzvwZwJ20",
        authDomain: "todo-3d27e.firebaseapp.com",
        databaseURL: "https://todo-3d27e.firebaseio.com",
        projectId: "todo-3d27e",
        storageBucket: "todo-3d27e.appspot.com",
        messagingSenderId: "116842860015"
    };
    firebase.initializeApp(config);

    $("#loginBtn").click(function () {

        var email = $("#email").val();
        var password = $("#password").val();
        firebase.auth().signInWithEmailAndPassword(email, password)
            .then(function () {
                window.location.href = "index.html";
            }).catch(function (error) {
                alert(error.message);
            })


    })

})
$('input[type="submit"]').click(function(){
    $('.login').addClass('test')
    setTimeout(function(){
      $('.login').addClass('testtwo')
    },300);
    setTimeout(function(){
      $(".authent").show().animate({right:-320},{easing : 'easeOutQuint' ,duration: 600, queue: false });
      $(".authent").animate({opacity: 1},{duration: 200, queue: false }).addClass('visible');
    },500);
    setTimeout(function(){
      $(".authent").show().animate({right:90},{easing : 'easeOutQuint' ,duration: 600, queue: false });
      $(".authent").animate({opacity: 0},{duration: 200, queue: false }).addClass('visible');
      $('.login').removeClass('testtwo')
    },2500);
    setTimeout(function(){
      $('.login').removeClass('test')
      $('.login div').fadeOut(123);
    },2800);
    setTimeout(function(){
      $('.success').fadeIn();
    },3200);
  });
  
  $('input[type="text"],input[type="password"]').focus(function(){
    $(this).prev().animate({'opacity':'1'},200)
  });
  $('input[type="text"],input[type="password"]').blur(function(){
    $(this).prev().animate({'opacity':'.5'},200)
  });
  
  $('input[type="text"],input[type="password"]').keyup(function(){
    if(!$(this).val() == ''){
      $(this).next().animate({'opacity':'1','right' : '30'},200)
    } else {
      $(this).next().animate({'opacity':'0','right' : '20'},200)
    }
  });
  
  var open = 0;
  $('.tab').click(function(){
    $(this).fadeOut(200,function(){
      $(this).parent().animate({'left':'0'})
    });
  });
  
  