$(document).ready(function () {
    var config = {
        apiKey: "AIzaSyCdtLZwM1uMAAt9xDtjllkul0QzvwZwJ20",
        authDomain: "todo-3d27e.firebaseapp.com",
        databaseURL: "https://todo-3d27e.firebaseio.com",
        projectId: "todo-3d27e",
        storageBucket: "todo-3d27e.appspot.com",
        messagingSenderId: "116842860015"
    };
    firebase.initializeApp(config);


    //check sessions
    firebase.auth().onAuthStateChanged(function (user) {
        var current_user = "";

        if (user) {
            //get current user id
            current_user = user.uid;
            //console.log(current_user);


            //logout function
            $("#logout").click(function () {
                firebase.auth().signOut().then(function () {
                    window.location.href = "login.html"
                })
            })

            // Insert data to cloud
            $(".sendToFireBase").click(function () {
                var name = $("#name").val();
                var date = $("#date").val();
                var description = $("#description").val();

                firebase.database().ref().child("users").child(current_user).child("todos").push({
                    name: name,
                    date: date,
                    description: description,
                    completed: false
                });
                $("#name").val('');
                $("#description").val('');

            })

            //get data\
            var todoRef = firebase.database().ref().child("users/" + current_user).child("todos");
            todoRef.on("value", function (snapshot) {

                var $parent = $(".col-xs-12").children(".card-deck");

                $parent.html('');

                snapshot.forEach(function (item) {

                    var completed = item.val().completed == true ? "checked" : "";
                    var name_elem = "<h5 class='card-title'>" + item.val().name + "</h5>";
                    var description_elem = "<p class='card-text'>" + item.val().description + "</small></p>";
                    var date_elem = "<p class='card-text'><small class='text-muted'>" + item.val().date + "</p>";
                    var completed_elem = "<div class='unpublish d-none'><input data-key='" + item.key + "' type='checkbox' class='switchery-plugin' " + completed + "/></div>";
                    var removeBtn_elem = "<div class='delete'><button data-key='" + item.key + "' class='btn btn-danger btn-block removeBtn'>Delete</button></div>";

                    $parent.append(" <div class='card '><div class='card-body'>" + name_elem + date_elem + description_elem + completed_elem + removeBtn_elem + "</div></div>");

                })

                $(".switchery-plugin").each(function () {
                    new Switchery(this);
                })
            });
            $("body").on("click", ".removeBtn", function () {
                var $key = $(this).data("key");
                firebase.database().ref("users/" + current_user).child("todos").child($key).remove();

            });

            $("body").on("change", ".switchery-plugin", function () {
                var $completed = $(this).prop("checked");
                var $key = $(this).data("key");
                firebase.database().ref("users/" + current_user).child("todos").child($key).child("completed").set($completed);
            })
        }
    })

    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd;
    }

    if (mm < 10) {
        mm = '0' + mm;
    }

    today = mm + '/' + dd + '/' + yyyy;
    document.getElementById("date").innerHTML = today;
    
})