$(document).ready(function () {
    // Initialize Firebase
    var config = {
        apiKey: "AIzaSyCdtLZwM1uMAAt9xDtjllkul0QzvwZwJ20",
        authDomain: "todo-3d27e.firebaseapp.com",
        databaseURL: "https://todo-3d27e.firebaseio.com",
        projectId: "todo-3d27e",
        storageBucket: "todo-3d27e.appspot.com",
        messagingSenderId: "116842860015"
    };
    firebase.initializeApp(config);


    $("#registerBtn").click(function () {
        var email = $("#email").val();
        var password = $("#password").val();
        //console.log(email, password);
        firebase.auth().createUserWithEmailAndPassword(email, password)
            .then(function () {
            firebase.auth().signInWithEmailAndPassword(email, password).then(function () {
                window.location.href = "index.html";
            })
        }).catch(function (err) {
            alert(err.message)
        })

    })
})
